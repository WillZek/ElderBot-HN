let handler = async (m, { conn }) => {
let tag = `@${m.sender.split('@')[0]}`;
 let txt = `╔═══════════════╗
┇➤ 𝙃𝙊𝙇𝘼, 𝙃𝙐𝙈𝘼𝙉𝙊
┇ *${tag}* 
╚═══════════════╝

» 𝘉𝘪𝘦𝘯𝘷𝘦𝘯𝘪𝘥𝘰, 𝘦𝘴𝘵𝘦 𝘦𝘴 𝘶𝘯 𝘮𝘦𝘯𝘶́ 𝘳𝘦𝘴𝘶𝘮𝘪𝘥𝘰 𝘥𝘦 𝘵𝘰𝘥𝘰 𝘭𝘰 𝘲𝘶𝘦 𝘤𝘰𝘯𝘵𝘪𝘦𝘯𝘦 𝘌𝘭𝘥𝘦𝘳-𝘣𝘰𝘵.

*\`ɪɴꜰᴏ\`*

☆ 👨🏻‍💻 *ᴘᴇʀꜰɪʟ*
☆ 👨🏻‍💻 *ᴍᴇɴᴜ*
☆ 👨🏻‍💻 *ᴏᴡɴᴇʀ*
☆ 👨🏻‍💻 *ᴛᴏᴛᴀʟғᴜɴᴄɪᴏɴᴇs*
☆ 👨🏻‍💻 *ʀᴜɴᴛɪᴍᴇ*
☆ 👨🏻‍💻 *ʙᴏᴛʀᴇɢʟᴀs*
☆ 👨🏻‍💻 *ᴀғᴋ <ᴛᴇx>*
☆ 👨🏻‍💻 *sᴛᴀғғ*
☆ 👨🏻‍💻 *ʙʟᴏᴄᴋʟɪsᴛ*

*\`ᴀɪ\`*

☆ 🎯 *ʀᴇᴍɪɴɪ*
☆ 🎯 *ʜᴅ*
☆ 🎯 *ᴇɴʜᴀɴᴄᴇ*
☆ 🎯 *ᴡᴀʟʟᴘᴀᴘᴇʀ <ᴛxᴛ>*
☆ 🎯 *ɢᴇᴍɪɴɪ / ɪᴀ*
☆ 🎯 *ᴘɪxᴀɪ*

 *\`ʙᴜꜱᴏ̨ᴜᴇᴅᴀꜱ\`*

☆ 🕵🏻‍♂️ *ɢᴏᴏɢʟᴇ <ʙᴜ́ꜱǫᴜᴇᴅᴀ>*
☆ 🕵🏻‍♂️ *ᴛɪᴋᴛᴏᴋꜱᴇᴀʀᴄʜ <ᴛxᴛ>*
☆ 🕵🏻‍♂️ *ʏᴛꜱᴇᴀʀᴄʜ*
☆ 🕵🏻‍♂️ *ɪᴍᴀɢᴇɴ <ᴛxᴛ>*
☆ 🕵🏻‍♂️ *ᴘʟᴀʏ* <ᴍᴜꜱɪᴄᴀ>
☆ 🕵🏻‍♂️ *ʏᴛᴅʟᴍᴘ4* <ɴᴏᴍʙʀᴇ>
☆ 🕵🏻‍♂️ *ʏᴛᴅʟᴍᴘ3* <ɴᴏᴍʙʀᴇ>

‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌‍‌‍‌‍‌‍‌‍‌‌‍‍‍‍‌
 *\`ᴊᴜᴇɢᴏꜱ\`*

☆ 🕹️ *ɢᴀʏ <@ᴛᴀɢ>*
☆ 🕹️ *ᴍᴀɴᴄᴏ <@ᴛᴀɢ>*
☆ 🕹️ *ᴍᴀɴᴄᴀ <@ᴛᴀɢ>*
☆ 🕹️ *ᴘᴜᴛᴏ <@ᴛᴀɢ>*
☆ 🕹️ *ᴘᴜᴛᴀ <@ᴛᴀɢ>*
☆ 🕹️ *ᴘᴀᴊᴇʀᴏ <@ᴛᴀɢ>*
☆ 🕹️ *ᴘᴀᴊᴇʀᴀ <@ᴛᴀɢ>*
☆ 🕹️ *ʀᴀᴛᴀ <@ᴛᴀɢ>*
☆ 🕹️ *ᴅᴀᴅᴏ <@ᴛᴀɢ>*
☆ 🕹️ *ᴅᴇᴄʟᴀʀᴀᴄɪᴏ́ɴ*
☆ 🕹️ *ғᴏʀᴍᴀʀᴘᴀʀᴇᴊᴀ*
☆ 🕹️ *ʀᴇᴛᴏ*
☆ 🕹️ *sᴏᴘᴀ*
☆ 🕹️ *ʟᴏᴠᴇ*
☆ 🕹️ *ʟᴏᴠᴇ2 <@ᴛᴀɢ>*
☆ 🕹️ *ᴍᴇᴍᴇ*
☆ 🕹️ *ʀᴜʟᴇᴛᴀ*
☆ 🕹️ *ᴀʙʀᴀᴢᴀʀ <@ᴛᴀɢ>*
☆ 🕹️ *ᴀᴄᴇʀᴛɪᴊᴏ*
☆ 🕹️ *ꜱᴏɴʀᴏᴊᴀʀꜱᴇ <@ᴛᴀɢ>*
☆ 🕹️ *ᴄᴏɴꜱᴇᴊᴏ*
☆ 🕹️ *ᴇɴᴀᴍᴏʀᴀᴅᴀ <@ᴛᴀɢ>*
☆ 🕹️ *ᴍᴇᴍᴇ*
☆ 🕹️ *ᴀᴄᴀʀɪᴄɪᴀʀ <@ᴛᴀɢ>*
☆ 🕹️ *ᴘᴇʀꜱᴏɴᴀʟɪᴅᴀᴅ*
☆ 🕹️ *ᴘɪʀᴏᴘᴏ*
☆ 🕹️ *ᴘᴏᴋᴇᴅᴇx <ᴘᴏᴋᴇᴍᴏ́ɴ>*
☆ 🕹️ *ᴘʀᴇɢᴜɴᴛᴀ*
☆ 🕹️ *ᴅᴏʀᴍɪʀ <@ᴛᴀɢ>*
☆ 🕹️ *ᴛʀɪꜱᴛᴇ <@ᴛᴀɢ>*
☆ 🕹️ *ᴛᴏᴘ <ᴛxᴛ>*
☆ 🕹️ *ᴢᴏᴅɪᴀᴄ <2010 03 15*

 *\`ʀᴘɢ\`*

☆ 📌 *ʙᴀʟ*
☆ 📌 *ᴄʀɪᴍᴇɴ*
☆ 📌 *ᴅᴀɪʟʏ*
☆ 📌 *ᴄʟᴀɪᴍ*
☆ 📌 *ᴅᴇᴘᴏꜱɪᴛᴀʀ*
☆ 📌 *ʟʙ*
☆📌 *ʀᴇᴛɪʀᴀʀ*
☆ 📌 *ʀᴏʙ2*
☆ 📌 *ʀᴏʙ*
☆ 📌 *ᴛʀᴀʙᴀᴊᴀʀ*
☆ 📌 *ʙᴜʏ*
☆ 📌 *ʙᴜʏ ᴀʟʟ*

 *\`ꜱᴛɪᴄᴋᴇʀꜱ\`*

☆ 🎭 *ǫᴄ*
☆ 🎭 *ꜱᴛɪᴋᴇʀ <ɪᴍɢ>*
☆ 🎭 *ꜱᴛɪᴄᴋᴇʀ <ᴜʀʟ>*
☆ 🎭 *ᴛᴀᴋᴇ <ɴᴏᴍʙʀᴇ/ᴀᴜᴛᴏʀ>*

 *\`+18\`*

☆ 🔞 *xɴxxꜱᴇᴀʀᴄʜ <ᴛxᴛ>*
☆ 🔞 *xɴxxᴅʟ <ʟɪɴᴋ>*

 *\`ɢʀᴜᴘᴏꜱ\`*

☆ 👑 *ʟɪɴᴋ*
☆ 👑 *ɢʀᴜᴘᴏ ᴏᴘᴇɴ / ᴄʟᴏꜱᴇ*
☆ 👑 *ᴅᴇʟᴇᴛᴇ*
☆ 👑 *ᴅᴇᴍᴏᴛᴇ*
☆ 👑 *ᴘʀᴏᴍᴏᴛᴇ*
☆ 👑 *ᴇɴᴄᴜᴇꜱᴛᴀ <ᴛxᴛ / ᴛxᴛ>*
☆ 👑 *ʜɪᴅᴇᴛᴀɢ*
☆ 👑 *ɪɴꜰᴏɢʀᴜᴘᴏ*
☆ 👑 *ᴋɪᴄᴋ*
☆ 👑 *ʟɪꜱᴛᴀᴅᴠ*
☆ 👑 *ᴛᴀɢᴀʟʟ <ᴛxᴛ>*
☆ 👑 *ɪɴᴠᴏᴄᴀʀ <ᴛxᴛ>*
☆ 👑 *ʙᴀɴᴄʜᴀᴛ*
☆ 👑 *ᴜɴʙᴀɴᴄʜᴀᴛ*
☆ 👑 *ʙᴀɴᴜsᴇʀ <@ᴛᴀɢ>*
☆ 👑 *ᴜɴʙᴀɴᴜsᴇʀ <@ᴛᴀɢ>*
☆ 👑 *ʀᴜʟᴇᴛᴀʙᴀɴ*
☆ 👑 *ɪɴᴀᴄᴛɪᴠᴏs*
☆ 👑 *ᴀᴅᴍɪɴs <ᴛxᴛ>*
☆ 👑 *sᴏʀᴛᴇᴏ*

 *\`ᴏɴ/ᴏꜰꜰ\`*

☆ ⚙️ *ᴇɴᴀʙʟᴇ*
☆ ⚙️ *ᴅɪꜱᴀʙʟᴇ*

 *\`ᴅᴇꜱᴄᴀʀɢᴀꜱ\`*

☆ 📂 *ꜰᴀᴄᴇʙᴏᴏᴋ - ꜰʙ*
☆ 📂 *ɪᴍᴀɢᴇɴ <ᴛxᴛ>*
☆ 📂 *ɪɴꜱᴛᴀɢʀᴀᴍ - ɪɢ*
☆ 📂 *ᴛɪᴋᴛᴏᴋ*
☆ 📂 *ʏᴛᴍᴘ4*
☆ 📂 *ʏᴛᴍᴘ3*
☆ 📂 *ᴄʟɪᴍᴀ*
☆ 📂 *ᴅᴇᴍᴏ*
☆ 📂 *ғᴜx*
☆ 📂 *ғᴀᴋᴇ*
☆ 📂 *ɢᴇᴛ*
☆ 📂 *ᴅɪғᴜᴍɪɴᴀʀ*

 *\`ʜᴇʀʀᴀᴍɪᴇɴᴛᴀꜱ\`*

☆ ⚙️ *ᴛᴏᴀɴɪᴍᴇ*
☆ ⚙️ *ʀᴇᴍɪɴɪ*
☆ ⚙️ *ʜᴅ*
☆ ⚙️ *ᴇɴʜᴀɴᴄᴇ*
☆ ⚙️ *ꜱꜱᴡᴇʙ*
☆ ⚙️ *ꜱꜱ*
☆ ⚙️ *ᴛʀᴀᴅ*

 *\`ᴄᴏɴᴠᴇʀᴛɪᴅᴏʀᴇꜱ\`*

☆ 🎋 *ᴛᴏɢɪꜰᴀᴜᴅ*
☆ 🎋 *ᴛᴏɪᴍɢ*
☆ 🎋 *ᴛᴏᴀᴜᴅɪᴏ*

*\`ʟᴏɢᴏs\`*

☆ ⚡ *ʟᴏɢᴏᴄᴏʀᴀᴢᴏɴ*
☆ ⚡ *ʟᴏɢᴏɴᴀʀᴜᴛᴏ*
☆ ⚡ *ʟᴏɢᴏᴘᴀʀᴇᴊᴀ*
☆ ⚡ *ʟᴏɢᴏɢᴀᴛɪᴛᴏ*
☆ ⚡ *ʟᴏɢᴏɴᴇᴏɴ*
☆ ⚡ *ʟᴏɢᴏsᴏʟɪᴛᴀʀɪᴏ*
☆ ⚡ *ʟᴏɢᴏғᴜʀɪsᴛᴀ*
☆ ⚡ *ʟᴏɢᴏɴᴜʙᴇ*
☆ ⚡ *ʟᴏɢᴏᴀɴɢᴇʟ*
☆ ⚡ *ʟᴏɢᴏᴍᴜʀᴄɪᴇʟᴀɢᴏ*
☆ ⚡ *ʟᴏɢᴏʜᴏʀʀᴏʀ*
☆ ⚡ *ʟᴏɢᴏᴄɪᴇʟᴏ*
☆ ⚡ *ʟᴏɢᴏᴘᴏʀᴛᴀᴅᴀғғ*
☆ ⚡ *ʟᴏɢᴏᴘᴜɢ*
☆ ⚡ *ʟᴏɢᴏɢᴜᴇʀʀᴇʀᴏ*
> *© ⍴᥆ᥕᥱrᥱძ ᑲᥡ һᥒ ᥱᥣძᥱr*`.trim();

m.react('🔰');
let perfil = await conn.profilePictureUrl(m.sender, 'image').catch(_ => 'https://i.ibb.co/5xMs19nx/file.jpg');

/* await conn.sendMessage(m.chat, { text: txt, contextInfo: { externalAdReply: { title: botname, body: dev, thumbnailUrl: banner, mediaType: 1, showAdAttribution: true, renderLargerThumbnail: true }}} , { quoted: m })
};
*/
let bann = 'https://cdnmega.vercel.app/media/9wB1HLrT@Jcn5yrz18NjokOpmyK-SS9u-OZc4SyK_2rsVxxQ6wXI';

conn.sendMessage(m.chat, { image: { url: bann }, caption: txt }, { quoted: m });
}

handler.command = ['allmenu', 'menu', 'menuall', 'menucompleto'];

export default handler;

/* import { promises } from 'fs'
import { join } from 'path'
import fetch from 'node-fetch'
import { xpRange } from '../lib/levelling.js'

let tags = {
  'crow': '✨「 *`MENUS ELDER-BOT`* 」👑',
  'main': '「INFO」🍨',
  'buscador': '「BUSQUEDAS」🍨',
  'fun': '「JUEGOS」🍨',
  'serbot': '「SUB BOTS」🍨',
  'rpg': '「RPG」🍨',
  'rg': '「REGISTRO」🍨',
  'sticker': '「STICKERS」🍨',
  'emox': '「ANIMES」🍨',
  'database': '「DATABASE」🍨',
  'grupo': '「GRUPOS」🍨',
  'nable': '「ON / OFF」', 
  'descargas': '「DESCARGAS」🍨',
  'tools': '「HERRAMIENTAS」🍨',
  'info': '「INFORMACIÓN」🍨',
  'owner': '「CREADOR」🍨',
  'logos': '「EDICION LOGOS」🍨', 
}

const imgg = ['https://files.catbox.moe/i7uo2l.jpg', 'https://files.catbox.moe/i7uo2l.jpg', 'https://files.catbox.moe/i7uo2l.jpg']

//   before: `*•:•:•:•:•:•:•:•:•:•☾☼☽•:•.•:•.•:•:•:•:•:•*
const defaultMenu = {
"*%greeting* Hola %name"

» 𝘉𝘪𝘦𝘯𝘷𝘦𝘯𝘪𝘥𝘰, 𝘦𝘴𝘵𝘦 𝘦𝘴 𝘶𝘯 𝘮𝘦𝘯𝘶́ 𝘳𝘦𝘴𝘶𝘮𝘪𝘥𝘰 𝘥𝘦 𝘵𝘰𝘥𝘰 𝘭𝘰 𝘲𝘶𝘦 𝘤𝘰𝘯𝘵𝘪𝘦𝘯𝘦 𝘌𝘭𝘥𝘦𝘳-𝘣𝘰𝘵.
%readmore

\t*(✰◠‿◠) 𝐂 𝐨 𝐦 𝐚 𝐧 𝐝 𝐨 𝐬*   
`.trimStart(),
  header: '*┏━━━━━✦━━━━━┓*\n %category \n*┗━━━━━✦━━━━━┛*',
  body: '┊➤ %cmd',
  footer: '*┗━*\n',
  after: `> ${dev}`,
}
let handler = async (m, { conn, usedPrefix: _p, __dirname }) => {
  try {
    let _package = JSON.parse(await promises.readFile(join(__dirname, '../package.json')).catch(_ => ({}))) || {}
    let { exp, estrellas, level, role } = global.db.data.users[m.sender]
    let { min, xp, max } = xpRange(level, global.multiplier)
    let name = await conn.getName(m.sender)
    exp = exp || 'Desconocida';
    role = role || 'Aldeano';
    let d = new Date(new Date + 3600000)
    let locale = 'es'
    let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
    let week = d.toLocaleDateString(locale, { weekday: 'long' })
    let date = d.toLocaleDateString(locale, {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
    let dateIslamic = Intl.DateTimeFormat(locale + '-TN-u-ca-islamic', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    }).format(d)
let botinfo = (conn.user.jid == global.conn.user.jid ? 'Oficial' : 'Sub-Bot');

    let time = d.toLocaleTimeString(locale, {
      hour: 'numeric',
      minute: 'numeric',
      second: 'numeric'
    })
    let _uptime = process.uptime() * 1000
    let _muptime
    if (process.send) {
      process.send('uptime')
      _muptime = await new Promise(resolve => {
        process.once('message', resolve)
        setTimeout(resolve, 1000)
      }) * 1000
    }
    let muptime = clockString(_muptime)
    let uptime = clockString(_uptime)
    let totalreg = Object.keys(global.db.data.users).length
    let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length
    let help = Object.values(global.plugins).filter(plugin => !plugin.disabled).map(plugin => {
      return {
        help: Array.isArray(plugin.tags) ? plugin.help : [plugin.help],
        tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
        prefix: 'customPrefix' in plugin,
        estrellas: plugin.estrellas,
        premium: plugin.premium,
        enabled: !plugin.disabled,
      }
    })
    for (let plugin of help)
      if (plugin && 'tags' in plugin)
        for (let tag of plugin.tags)
          if (!(tag in tags) && tag) tags[tag] = tag
    conn.menu = conn.menu ? conn.menu : {}
    let before = conn.menu.before || defaultMenu.before
    let header = conn.menu.header || defaultMenu.header
    let body = conn.menu.body || defaultMenu.body
    let footer = conn.menu.footer || defaultMenu.footer
    let after = conn.menu.after || (conn.user.jid == conn.user.jid ? '' : `Powered by https://wa.me/${conn.user.jid.split`@`[0]}`) + defaultMenu.after
    let _text = [
      before,
      ...Object.keys(tags).map(tag => {
        return header.replace(/%category/g, tags[tag]) + '\n' + [
          ...help.filter(menu => menu.tags && menu.tags.includes(tag) && menu.help).map(menu => {
            return menu.help.map(help => {
              return body.replace(/%cmd/g, menu.prefix ? help : '%p' + help)
                .replace(/%isdiamond/g, menu.diamond ? '(ⓓ)' : '')
                .replace(/%isPremium/g, menu.premium ? '(Ⓟ)' : '')
                .trim()
            }).join('\n')
          }),
          footer
        ].join('\n')
      }),
      after
    ].join('\n')
    let text = typeof conn.menu == 'string' ? conn.menu : typeof conn.menu == 'object' ? _text : ''
let replace = {
'%': '%',
p: _p, uptime, muptime,
me: conn.getName(conn.user.jid),
taguser: '@' + m.sender.split("@s.whatsapp.net")[0],
npmname: _package.name,
npmdesc: _package.description,
version: _package.version,
exp: exp - min,
maxexp: xp,
botofc: (conn.user.jid == global.conn.user.jid ? '💛 𝙴𝚂𝚃𝙴 𝙴𝚂 𝙴𝙻 𝙱𝙾𝚃 𝙾𝙵𝙲' : `💛 𝚂𝚄𝙱-𝙱𝙾𝚃 𝙳𝙴: Wa.me/${global.conn.user.jid.split`@`[0]}`), 
totalexp: exp,
xp4levelup: max - exp,
github: _package.homepage ? _package.homepage.url || _package.homepage : '[unknown github url]',
greeting, level, estrellas, name, weton, week, date, dateIslamic, time, totalreg, rtotalreg, role,
readmore: readMore
}
text = text.replace(new RegExp(`%(${Object.keys(replace).sort((a, b) => b.length - a.length).join`|`})`, 'g'), (_, name) => '' + replace[name])

await m.react(emojis) 

/* conn.sendMessage(m.chat, {text: text.trim(), mentions: [...text.matchAll(/@([0-9]{5,16}|0)/g)].map((v) => v[1] + '@s.whatsapp.net'), contextInfo: { mentionedJid: [...text.matchAll(/@([0-9]{5,16}|0)/g)].map((v) => v[1] + '@s.whatsapp.net'), "externalAdReply": {"showAdAttribution": true, "renderLargerThumbnail": true, "containsAutoReply": true, "mediaType": 1, "thumbnailUrl": 'https://i.ibb.co/5xMs19nx/file.jpg' }}}, {quoted: m})


conn.sendMessage(m.chat, { image: { url: 'https://i.ibb.co/5xMs19nx/file.jpg' }, caption: text.trim() }, { quoted: m });

  } catch (e) {
    conn.reply(m.chat, `❌️ Lo sentimos, el menú tiene un error ${e.message}`, m, rcanal, )
    throw e
  }
}
handler.help = ['menu']
handler.tags = ['main']
handler.command = ['menu', 'help', 'menuall', 'allmenú', 'allmenu', 'menucompleto'] 
handler.register = false

export default handler

const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

function clockString(ms) {
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000)
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60
  return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':')
}

  var ase = new Date();
  var hour = ase.getHours();
switch(hour){
  case 0: hour = 'Bᴜᴇɴᴀs Nᴏᴄʜᴇs 🌙'; break;
  case 1: hour = 'Bᴜᴇɴᴀs Nᴏᴄʜᴇs 💤'; break;
  case 2: hour = 'Bᴜᴇɴᴀs Nᴏᴄʜᴇs 🦉'; break;
  case 3: hour = 'Bᴜᴇɴᴏs Dɪᴀs ✨'; break;
  case 4: hour = 'Bᴜᴇɴᴏs Dɪᴀs 💫'; break;
  case 5: hour = 'Bᴜᴇɴᴏs Dɪᴀs 🌅'; break;
  case 6: hour = 'Bᴜᴇɴᴏs Dɪᴀs 🌄'; break;
  case 7: hour = 'Bᴜᴇɴᴏs Dɪᴀs 🌅'; break;
  case 8: hour = 'Bᴜᴇɴᴏs Dɪᴀs 💫'; break;
  case 9: hour = 'Bᴜᴇɴᴏs Dɪᴀs ✨'; break;
  case 10: hour = 'Bᴜᴇɴᴏs Dɪᴀs 🌞'; break;
  case 11: hour = 'Bᴜᴇɴᴏs Dɪᴀs 🌨'; break;
  case 12: hour = 'Bᴜᴇɴᴏs Dɪᴀs ❄'; break;
  case 13: hour = 'Bᴜᴇɴᴏs Dɪᴀs 🌤'; break;
  case 14: hour = 'Bᴜᴇɴᴀs Tᴀʀᴅᴇs 🌇'; break;
  case 15: hour = 'Bᴜᴇɴᴀs Tᴀʀᴅᴇs 🥀'; break;
  case 16: hour = 'Bᴜᴇɴᴀs Tᴀʀᴅᴇs 🌹'; break;
  case 17: hour = 'Bᴜᴇɴᴀs Tᴀʀᴅᴇs 🌆'; break;
  case 18: hour = 'Bᴜᴇɴᴀs Nᴏᴄʜᴇs 🌙'; break;
  case 19: hour = 'Bᴜᴇɴᴀs Nᴏᴄʜᴇs 🌃'; break;
  case 20: hour = 'Bᴜᴇɴᴀs Nᴏᴄʜᴇs 🌌'; break;
  case 21: hour = 'Bᴜᴇɴᴀs Nᴏᴄʜᴇs 🌃'; break;
  case 22: hour = 'Bᴜᴇɴᴀs Nᴏᴄʜᴇs 🌙'; break;
  case 23: hour = 'Bᴜᴇɴᴀs Nᴏᴄʜᴇs 🌃'; break;
}
  var greeting = hour;
*/