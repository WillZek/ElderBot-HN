import { spawn } from 'child_process';

let handler = async (m, { conn, isROwner, text }) => {
    if (!process.send) throw '*『✦』Reiniciar: node start.js*\n*『✦』Reiniciar: node index.js*';

    if (conn.user.jid === conn.user.jid) {
        const progreso = [
      "*🕒 iniciando proceso de reinicio de ElderBot*",
            "□□□□□□ 0%",
            "■□□□□□ 20%",
            "■■□□□□ 30%",
            "■■■□□□ 50%",
            "■■■■□□ 60%",
            "■■■■■□ 80%",
            "■■■■■■ 100%",
        ];

        const { key } = await conn.sendMessage(m.chat, { text: progreso[0] }, { quoted: m });

        for (let i = 1; i < progreso.length; i++) {
            await delay(1000);

            await conn.sendMessage(m.chat, { text: progreso[i], edit: key });
        }

        await conn.sendMessage(m.chat, { text: "✅ 𝗘𝗹𝗱𝗲𝗿𝗕𝗼𝘁 reiniciado con éxito espera unos segundos asta que el proceso termine.", edit: key }, { externalAdReply: { title: botname, body: dev, sourceUrl: channel });

        await delay(2000);
        process.send('reset');
    } else {
        throw 'No tienes permisos para ejecutar este comando.';
    }
};

handler.help = ['restart'];
handler.tags = ['tools'];
handler.command = ['restart', 'xd', 'reiniciar'];
handler.rowner = true;

export default handler;

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));