// Código Hecho Por Niño Piña wa.me/50557865603
let handler = async (m, { conn }) => {
// React con un emoji al mensaje para que no sea tan aburrido
m.react('🌞');
// Siuuuuuuuuu
const message = "⏰ *DESPERTADOR* ⏰ Levántense webones 💪🥵";
if (m.isGroup) {
// CrowBot🔥
const videoUrl = 'https://files.catbox.moe/xss6jx.mp4'; //  Levantense🗣️🔥🔥
await conn.sendMessage(m.chat, { video: { url: videoUrl }, caption: message }, { mimetype: 'video/mp4' });
}
}
handler.help = ['despertar'];
handler.tags = ['grupo'];
handler.command = ['despertar', 'despierten'];
handler.group = true;
export default handler;