/*
import fetch from 'node-fetch'

let handler  = async (m, { conn, usedPrefix, command }) => {

let grupos = `╭┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈≫\n\n☕︎︎ *Hola!, te invito a unirte a los grupos oficiales del Bot para convivir con la comunidad oficial* 💛

1- 『✯ ⏤͟͞ू⃪𝗧𝗲𝗮𝗺 𝗖𝗼𝗺𝘂𝗻𝗶𝘁𝘆 𝗘𝗹𝗱𝗲𝗿𝗕𝗼𝘁⁞࿐ ✯』
*❑* ${grupo}

✧⋄⋆⋅⋆⋄✧⋄⋆⋅⋆⋄✧⋄⋆⋅⋆⋄✧⋄⋆⋅⋆⋄✧⋄⋆⋅⋆⋄✧

➠ Enlace anulado? entre aquí! 

[🌠] 𓆩 *Canal Crow's Club* ⁞✰⃔࿐:
*❏* ${channel}

> ${textbot}

╰┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈≫`

await conn.sendFile(m.chat, imagen1, "Crow.jpg", grupos, m, null, rcanal)

await m.react(emojis)

}
handler.help = ['grupos']
handler.tags = ['main']
handler.command = ['grupos', 'crowgrupos', 'gruposcrow']

export default handler
*/