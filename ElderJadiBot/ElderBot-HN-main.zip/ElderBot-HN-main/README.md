## **`E L D E R - B O T`**
> Bot De Uso Privado ✨
![Menu](https://files.catbox.moe/i7uo2l.jpg)

> Powered By [HN ELDER](https://github.com/WillZek)